Hard crackme. No patching! (You can patch antidebug ofc)
Try to find secret key to get "Correct password" to print to the chat.

Difficulty 3-4?

If you need hints, please read hint.txt.